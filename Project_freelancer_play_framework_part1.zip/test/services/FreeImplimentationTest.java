package services;

import org.junit.Test;

import static org.junit.Assert.*;
/**
 * test class for FreeImplimentationTest
 * @author Seung Hyun Hong, Tamanna Jahin, Nastaran Naseri, Herve Ngomseu Fosting
 */
public class FreeImplimentationTest {

    /**
     * test the Getter of the Projects
     */
    @Test
    public void getProjects() {
    }

    /**
     * test for Getter of the ID of Projects
     */
    @Test
    public void getIDProjects() {
    }

    /**
     * test for Getter the ownerResult
     */
    @Test
    public void getOwnerResult() {
    }

    /**
     * test for Setter of BaseURL
     */
    @Test
    public void setBaseUrl() {
    }
}