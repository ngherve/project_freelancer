package services;

import models.Query;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * test class for IApiServiceTest
 * @author Seung Hyun Hong, Tamanna Jahin, Nastaran Naseri, Herve Ngomseu Fosting
 */
public class IApiServiceTest {
    public IApiService apiInterface;
    List<Query> queryList = new ArrayList<>();

//    @Test
//    public void getProjects() {
//        //assertTrue(apiInterface.getProjects(queryList,""));
//    }
//
//    @Test
//    public void getIDProjects() {
//        //assertNotNull(apiInterface.getIDProjects(queryList,""));
//    }
//
//    @Test
//    public void getOwnerResult() {
//       // assertNotNull(apiInterface.getOwnerResult(""));
//    }
}