# project_freelancer_analyser_webapp_restapi_seon6441
The overall goal is to develop a web application that can analyze the content on Freelancer.com using its REST API. Freelancer.com is a global freelancing and crowdsourcing marketplace with over 26 million users. Play Application: “ Free Lance lot ”. 
